import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { pool } from "../config/database.js";

const router = express.Router();

router.post("/register", async (req, res) => {
  try {
    const { email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = await pool.query(
      "INSERT INTO users (email, password) VALUES ($1, $2) RETURNING *",
      [email, hashedPassword]
    );

    res.redirect("/auth/login");
  } catch (err) {
    res.status(500).send("Error registering user");
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await pool.query("SELECT * FROM users WHERE email = $1", [
      email,
    ]);

    if (user.rows.length === 0) {
      return res.status(401).send("Invalid credentials");
    }

    const validPassword = await bcrypt.compare(password, user.rows[0].password);

    if (!validPassword) {
      return res.status(401).send("Invalid credentials");
    }

    const token = jwt.sign(
      {
        id: user.rows[0].id,
        email: user.rows[0].email,
        type: user.rows[0].type,
      },
      "your_jwt_secret",
      { expiresIn: "1h" }
    );

    // Set cookie with token
    res.cookie("token", token, {
      httpOnly: true,
      maxAge: 3600000, // 1 hour
    });

    // Redirect based on user type
    if (user.type === "admin") {
      res.redirect("/admin");
    } else {
      res.redirect("/");
    }
  } catch (err) {
    res.status(500).send("Error logging in");
  }
});

// Serve register page
router.get("/register", (req, res) => {
  res.render("register", { title: "Register" });
});

router.get("/logout", (req, res) => {
  res.clearCookie("token");
  res.redirect("/");
});

// Serve login page
router.get("/login", (req, res) => {
  res.render("login", { title: "Login" });
});

const authRoutes = router;

export { authRoutes };
