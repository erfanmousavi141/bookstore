import morgan from "morgan";
import express from "express";
import cookieParser from "cookie-parser";
import { authenticateToken, isAdmin } from "./middleware/auth.js";
import { authRoutes } from "./routes/auth.js";
import { pool } from "./config/database.js";


const PORT = 3000;

const app = express();

app.use(morgan("combined"));

// Set EJS as templating engine

app.set("view engine", "ejs");
app.set("views", "views");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use("/css", express.static("public/css"));

// Middleware to make user data available to all templates
app.use((req, res, next) => {
  const token = req.cookies.token;
  if (token) {
    try {
      const user = jwt.verify(token, "your_jwt_secret");
      res.locals.user = user;
    } catch (err) {
      res.locals.user = null;
    }
  } else {
    res.locals.user = null;
  }
  next();
});

// Home route
app.get("/", async (req, res) => {
  try {
    const books = await pool.query("SELECT * FROM books");
    res.render("index.ejs", {
      user: req.session.user,
      books: books.rows,
    });
  } catch (error) {
    res.status(500).json({ error: "Server error" });
  }
});

// Auth routes
app.use("/auth", authRoutes);

// Protected admin route
app.get("/admin", authenticateToken, isAdmin, (req, res) => {
  res.render("admin", {
    title: "Admin Panel",
    user: req.user,
  });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
