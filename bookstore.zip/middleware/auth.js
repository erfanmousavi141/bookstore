import jwt from 'jsonwebtoken';

const authenticateToken = (req, res, next) => {
    const token = req.cookies.token;
    
    if (!token) {
        return res.redirect('/auth/login');
    }
    
    try {
        const user = jwt.verify(token, 'your_jwt_secret');
        req.user = user;
        next();
    } catch (err) {
        res.clearCookie('token');
        return res.redirect('/auth/login');
    }
};

const isAdmin = (req, res, next) => {
    if (req.user && req.user.type === 'admin') {
        next();
    } else {
        res.status(403).render('error', {
            title: 'Access Denied',
            message: 'You need administrative privileges to access this page'
        });
    }
};

export  { authenticateToken, isAdmin };